# prime_nos

A tiny Python library to check if numbers are prime or coprime.

## Installation

```bash
pip install prime_nos
