from .core import is_prime, are_coprime

__version__ = "0.1.0"
