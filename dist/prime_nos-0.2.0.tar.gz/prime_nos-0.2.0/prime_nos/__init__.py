from .core import is_prime, are_coprime

__version__ = "0.2.0"
