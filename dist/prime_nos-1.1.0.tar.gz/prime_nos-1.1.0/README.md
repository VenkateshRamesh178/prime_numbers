# prime_nos

A tiny Python library to check if numbers are prime or coprime.

## Installation

```bash
pip install prime_nos

```
has 3 functions:
 - is_prime(n) - checks if n is prime or not
 - are_coprime(a,b) - checks if a and b are coprime or not
 - prime_range(a,b) - returns a list of all prime numbers between a and b